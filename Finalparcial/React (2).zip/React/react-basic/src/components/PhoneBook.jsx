import React from "react";

function PhoneBook(){
    return <div>This is the PhoneBook</div>;
}

export default PhoneBook;