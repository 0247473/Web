import React from "react";

function Agenda(){
    return <div>This is the Agenda</div>;
}

export default Agenda;
